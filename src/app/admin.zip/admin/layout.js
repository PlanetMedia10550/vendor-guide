import "@/assets/scss/theme.scss";
import Header from "./Header";
import Sidebar from "./Sidebar";
import Footer from "./Footer";


export default function AdminLayout({ children }) {
  return (
        <div id="layout-wrapper">
          <Header toggleMenuCallback="" />
          <Sidebar
            theme=""
            type=""
            isMobile=""
          />
          <div className="main-content">{children}</div>
          <Footer />
        </div>
  )
}
