"use client"
import PropTypes from "prop-types";
import React from "react";
import { connect } from "react-redux";
// import { withRouter } from "react-router-dom"
// import withRouter from "components/Common/withRouter";

//i18n
// import { withTranslation } from "react-i18next";
import SidebarContent from "./SidebarContent";

const Sidebar = () => {
  return (
    <React.Fragment>
      <div className="vertical-menu">
        <div data-simplebar className="h-100">
          <SidebarContent />
        </div>
      </div>
    </React.Fragment>
  );
};


export default Sidebar;
