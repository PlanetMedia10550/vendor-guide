"use client"
import PropTypes from 'prop-types';
import React, { useState } from "react";

import { connect } from "react-redux";
import { Form, Dropdown, DropdownMenu, DropdownItem, DropdownToggle, Input, Button } from "reactstrap";

// import { Link } from "react-router-dom";

// Import menuDropdown
// import LanguageDropdown from "@/CommonForBoth/TopbarDropdown/LanguageDropdown";
import NotificationDropdown from "@/components/TopbarDropdown/NotificationDropdown";
import ProfileMenu from "@/components/TopbarDropdown/ProfileMenu";

import logodarkImg from "@/assets/images/logo-dark.png";
import logosmImg from "@/assets/images/logo-sm.png";
import logolightImg from "@/assets/images/logo-light.png";
import Link from 'next/link';
import Image from 'next/image';


const Header = () => {
  const [menu, setMenu] = useState(false);
  const toggle = () => {
    setMenu(!menu);
  };

  function tToggle() {
    var body = document.body;
    if (window.screen.width <= 992) {
      body.classList.toggle("sidebar-enable");
    } else {
      body.classList.toggle("vertical-collpsed");
      body.classList.toggle("sidebar-enable");
    }
  }

  return (
    <React.Fragment>
      <header id="page-topbar">
        <div className="navbar-header">
          <div className="d-flex">
            <div className="navbar-brand-box">
              <Link href="/" className="logo logo-dark">
                <span className="logo-sm">
                  <Image src={logosmImg} alt="" height="22" />
                </span>
                <span className="logo-lg">
                  <Image src={logodarkImg} alt="" height="17" />
                </span>
              </Link>

              <Link href="/" className="logo logo-light">
                <span className="logo-sm">
                  <Image src={logosmImg} alt="" height="22" />
                </span>
                <span className="logo-lg">
                  <Image src={logolightImg} alt="" height="18" />
                </span>
              </Link>
            </div>
            <button type="button" className="btn btn-sm px-3 font-size-24 header-item waves-effect"
              id="vertical-menu-btn"
              onClick={() => {
                tToggle();
              }}
              data-target="#topnav-menu-content"
            >
              <i className="mdi mdi-menu"></i>
            </button>

            
          </div>

          <div className="d-flex">

            <NotificationDropdown />
            <ProfileMenu />

          </div>
        </div>
      </header>
    </React.Fragment>
  );
};




export default Header;
