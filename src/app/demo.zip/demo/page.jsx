// pages/index.js
import PageFlipComponent from './PageFlipComponent';

const Page = () => {
  return (
    <div>
      <PageFlipComponent />
    </div>
  );
};

export default Page;
